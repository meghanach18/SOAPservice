package com.example.soap.number;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URI;
import java.net.URL;

import com.dataaccess.webservicesserver.NumberConversion;
import com.dataaccess.webservicesserver.NumberConversionSoapType;

public class Number {

	public static void main(String[] args) throws IOException {
		 String endpoint ="https://www.dataaccess.com/webservicesserver/numberconversion.wso?WSDL";
		 URL url =URI.create(endpoint).toURL();
			
	         NumberConversion service = new NumberConversion(url);

	         NumberConversionSoapType port = service.getPort(NumberConversionSoapType.class);
	
	         
	         System.out.println("34 -->"+port.numberToWords(BigInteger.valueOf(34))+"$15.99-->"+port.numberToDollars(BigDecimal.valueOf(15.99)));
	    }

	}


