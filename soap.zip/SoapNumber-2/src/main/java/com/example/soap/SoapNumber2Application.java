package com.example.soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapNumber2Application {

	public static void main(String[] args) {
		SpringApplication.run(SoapNumber2Application.class, args);
	}

}
